These are archetypes exported from the Clinical Knowledge Manager.
Export time: Fri Mar 14 17:13:24 CET 2025